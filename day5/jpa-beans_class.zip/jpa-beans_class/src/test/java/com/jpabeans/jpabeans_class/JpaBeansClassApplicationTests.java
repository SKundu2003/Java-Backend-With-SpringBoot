package com.jpabeans.jpabeans_class;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpaBeansClassApplicationTests {

	@Test
	void contextLoads() {
	}

}
